from rest_framework.generics import GenericAPIView
from rest_framework.mixins import ListModelMixin, CreateModelMixin, RetrieveModelMixin, UpdateModelMixin, \
    DestroyModelMixin
from blog.models import blogPublicationModel
from .serializers import blogClientPublicationSerializer


# <editor-fold desc="GET ALL PUBLICATIONS LIST">
class blogClientPublicationList(GenericAPIView, ListModelMixin):
    queryset = blogPublicationModel.objects.all()
    serializer_class = blogClientPublicationSerializer

    def get(self, request, *args, **kwargs):
        return self.list(request, *args, **kwargs)
# </editor-fold>


# <editor-fold desc="PUBLICATION CREATE">
class blogClientPublicationCreate(GenericAPIView, CreateModelMixin):
    queryset = blogPublicationModel.objects.all()
    serializer_class = blogClientPublicationSerializer

    def post(self, request, *args, **kwargs):
        return self.create(request, *args, **kwargs)
# </editor-fold>


# <editor-fold desc="SINGLE PUBLICATION GET BY USING PUBLICATION SLUG RETRIEVE BY DEFAULT CALL">
class blogClientPublicationRetrive(GenericAPIView, RetrieveModelMixin):
    queryset = blogPublicationModel.objects.all()
    serializer_class = blogClientPublicationSerializer
    lookup_field = "slug"

    def get(self, request, *args, **kwargs):
        return self.retrieve(request, *args, **kwargs)
# </editor-fold>


# <editor-fold desc="UPDATE THE PUBLICATION BY USING PUBLICATION SLUG">
class blogClientPublicationUpdate(GenericAPIView, UpdateModelMixin):
    queryset = blogPublicationModel.objects.all()
    serializer_class = blogClientPublicationSerializer
    lookup_field = "slug"
    def put(self, request, *args, **kwargs):
        return self.update(request, *args, **kwargs)
# </editor-fold>


# <editor-fold desc="DELETE THE PUBLICATION BY USING PUBLICATION SLUG">
class blogClientPublicationDelete(GenericAPIView, DestroyModelMixin):
    queryset = blogPublicationModel.objects.all()
    serializer_class = blogClientPublicationSerializer
    lookup_field = "slug"
    def delete(self, request, *args, **kwargs):
        return self.destroy(request, *args, **kwargs)
# </editor-fold>



"""
WITHOUT ID PASSING 1
"""
# <editor-fold desc="PUBLICATION LIST AND CREATE">
class blogClientPublicationListAndCreate(GenericAPIView, ListModelMixin,CreateModelMixin):
    queryset = blogPublicationModel.objects.all()
    serializer_class = blogClientPublicationSerializer

    def get(self, request, *args, **kwargs):
        return self.list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return self.create(request, *args, **kwargs)
# </editor-fold>

"""
WITH ID PASSING 2
"""

# <editor-fold desc="PUBLICATION RETRIEVE WITH UPDATE AND DELETE BY USING PUBLICATION SLUG">
class blogClientPublicationRetriveUpdateDestroy(GenericAPIView, RetrieveModelMixin,UpdateModelMixin,DestroyModelMixin):
    queryset = blogPublicationModel.objects.all()
    serializer_class = blogClientPublicationSerializer
    lookup_field = "slug"

    def get(self, request, *args, **kwargs):
        return self.retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return self.update(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        return self.destroy(request, *args, **kwargs)
# </editor-fold>
