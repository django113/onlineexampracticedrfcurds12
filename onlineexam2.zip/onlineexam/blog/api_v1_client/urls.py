from django.urls import path

from blog.api_v1_client.views import blogClientPublicationList, blogClientPublicationCreate, \
    blogClientPublicationUpdate, blogClientPublicationDelete, blogClientPublicationRetriveUpdateDestroy, \
    blogClientPublicationListAndCreate

urlpatterns = [
    # <editor-fold desc="PUBLICATION GET ALL LIST">
    path('publication-list/', blogClientPublicationList.as_view(), name="blogClientPublicationListURL"),
    # </editor-fold>

    # <editor-fold desc="PUBLICATION CREATE">
    path('publication-create/', blogClientPublicationCreate.as_view(), name="blogClientPublicationCreateURL"),
    # </editor-fold>

    # <editor-fold desc="PUBLICATION UPDATE BY USING PUBLICATION SLUG">
    path('publication-update/<slug>/', blogClientPublicationUpdate.as_view(), name="blogClientPublicationUpdateURL"),
    # </editor-fold>

    # <editor-fold desc="PUBLICATION DELETE BY USING PUBLICATION SLUG">
    path('publication-delete/<slug>/', blogClientPublicationDelete.as_view(), name="blogClientPublicationDeleteURL"),
    # </editor-fold>

    #
    # <editor-fold desc="PUBLICATION CREATE AND GET ALL LIST ">
    path('publication-list-create/', blogClientPublicationListAndCreate.as_view(),
         name="blogClientPublicationListAndCreateURL"),
    # </editor-fold>

    # <editor-fold desc="PUBLICATION DETAILS BY USING PUBLICATION SLUG">
    path('publication-details/<slug>/', blogClientPublicationRetriveUpdateDestroy.as_view(),
         name="blogClientPublicationRetriveUpdateDestroyURL"),
    # </editor-fold>

]
