from rest_framework import serializers
from blog.models import blogArticleModel, blogPublicationModel


# <editor-fold desc="ARTICLE CREATE">
class blogAdminArticleSerializer(serializers.ModelSerializer):
    class Meta:
        model = blogArticleModel
        fields = '__all__'
# </editor-fold>


# <editor-fold desc="PUBLICATION CREATE">
class blogAdminPublicationSerializer(serializers.ModelSerializer):
    class Meta:
        model = blogPublicationModel
        fields = '__all__'
# </editor-fold>
