from django.urls import path

from blog.api_v1_admin.views import publication_list, publication_create, publication_update, publication_delete

urlpatterns = [
    # <editor-fold desc="GET ALL PUBLICATIONS LIST">
    path('publication-list/',publication_list,name="publication_listURL"),
    # </editor-fold>

    # <editor-fold desc="PUBLICATION CREATE">
    path('publication-create/',publication_create,name="publication_createURL"),
    # </editor-fold>

    # <editor-fold desc="PUBLICATION UPDATE BY USING PUBLICATION SLUG">
    path('publication-update/<slug>/',publication_update,name="publication_updateURL"),
    # </editor-fold>

    # <editor-fold desc="DELETE THE PUBLICATION BY USING SLUG">
    path('publication-delete/<slug>/',publication_delete,name="publication_deleteURL"),
    # </editor-fold>

]
