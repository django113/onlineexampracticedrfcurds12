from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response

from blog.models import blogPublicationModel, blogArticleModel
from .serializers import blogAdminPublicationSerializer, blogAdminArticleSerializer


# <editor-fold desc="GET ALL PUBLICATIONS LIST">
@api_view(['GET'])
def publication_list(request):
    publication_objects = blogPublicationModel.objects.all()
    serializer = blogAdminPublicationSerializer(publication_objects, many=True)
    print()
    print(publication_objects, "===publication objects")
    print()
    print(serializer, "=========serializers convert or json format")
    return Response({
        'status': status.HTTP_200_OK,
        'payload': serializer.data
    })


# </editor-fold>


# <editor-fold desc="CREATE PUBLICATION">
@api_view(['POST'])
def publication_create(request):
    publication_objects = blogPublicationModel.objects.all()
    serializer = blogAdminPublicationSerializer(data=request.data)  # change for post
    if serializer.is_valid():
        serializer.save()
    print()
    print(publication_objects, "===publication objects")
    print()
    print(serializer, "=========serializers convert or json format")
    return Response({
        'status': status.HTTP_201_CREATED,
        'payload': serializer.data
    })


# </editor-fold>

# <editor-fold desc="PUBLICATION IS UPDATED BY USING PUBLICATION SLUG">
@api_view(['PUT'])
def publication_update(request, slug):
    publication_objects = blogPublicationModel.objects.get(slug=slug)
    serializer = blogAdminPublicationSerializer(instance=publication_objects, data=request.data)  # change for post
    if serializer.is_valid():
        serializer.save()
    print()
    print(publication_objects, "===publication update objects")
    print()
    print(serializer, "=========serializers convert or json format")
    return Response({
        'status': status.HTTP_201_CREATED,
        'payload': serializer.data
    })
# </editor-fold>


# <editor-fold desc="PUBLICATION DELETED">
@api_view(['DELETE'])
def publication_delete(request, slug):
    publication_objects = blogPublicationModel.objects.get(slug=slug)
    publication_objects.delete()
    return Response({
        'status': status.HTTP_200_OK,
        'payload': "publication is deleted"
    })
# </editor-fold>
