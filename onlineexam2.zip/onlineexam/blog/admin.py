from django.contrib import admin

# Register your models here.
from blog.models import blogArticleModel,blogPublicationModel

admin.site.register(blogArticleModel)
admin.site.register(blogPublicationModel)
