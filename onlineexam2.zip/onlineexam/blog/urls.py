from django.urls import path, include

urlpatterns = [

    # <editor-fold desc="PUBLICATION">
    path('api/admin/v1/', include('blog.api_v1_admin.urls')),
    # </editor-fold>

    # <editor-fold desc="PUBLICATION">
    path('api/client/v1/', include('blog.api_v1_client.urls')),
    # </editor-fold>

]