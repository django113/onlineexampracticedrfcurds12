from rest_framework.routers import DefaultRouter
from .views import studentClientStudentCurd, studentClientStudentCurdViewset, studentClientDetailsApiview, \
    studentClientStudentListApiview
from django.urls import path, include

router = DefaultRouter()
# <editor-fold desc="STUDENT GET ALL,CREATE,UPDATE,DELETE UISNG MODELVIEWSET">
router.register('student_list', studentClientStudentCurd)
# </editor-fold>
#
# <editor-fold desc="STUDENT GET ALL,CREATE,UPDATE,DELETE USING VIEWSET">
router.register('student-list', studentClientStudentCurdViewset,
                basename='studentClientStudentCurdViewsetURL')
# </editor-fold>

urlpatterns = [
    path('', include(router.urls)),

    # <editor-fold desc="STUDENT CREATE AND GET ALL STUDENTS">
    path('studentcreate/',studentClientStudentListApiview.as_view(),name="studentClientStudentListURL"),
    # </editor-fold>
    # <editor-fold desc="STUDENT DETAILS BY USING STUDENT SLUG">
    path('studentdetails/<slug>/', studentClientDetailsApiview.as_view(), name="studentClientDetailsApiviewURL"),
    # </editor-fold>

]
