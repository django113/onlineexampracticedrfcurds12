import django_filters
from django.shortcuts import get_object_or_404
from rest_framework import viewsets, status, filters
from rest_framework.response import Response
from rest_framework.views import APIView

from student.models import studentStudentModel
from .serializers import studentClientStudentSerializer
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from rest_framework.pagination import LimitOffsetPagination, CursorPagination, PageNumberPagination
from rest_framework.authentication import BasicAuthentication, TokenAuthentication, SessionAuthentication
from rest_framework_simplejwt.authentication import JWTAuthentication


# <editor-fold desc="STUDENT CREATE,UPDATE,DELETE USING MODELVIEWSET">
class studentClientStudentCurd(viewsets.ModelViewSet):
    queryset = studentStudentModel.objects.all()
    serializer_class = studentClientStudentSerializer

    def perform_create(self, serializer):
        serializer.save(student=self.request.user)

    def perform_update(self, serializer):
        serializer.save(student=self.request.user)


# </editor-fold>


# VIEWSETS

# <editor-fold desc="STUDENT CURD WITH VIEWSETS">
class studentClientStudentCurdViewset(viewsets.ViewSet):
    def list(self, request):
        queryset = studentStudentModel.objects.all()
        serializer = studentClientStudentSerializer(queryset, many=True)
        return Response(serializer.data)

    def retrive(self, request, slug=None):
        slug = slug
        if slug is not None:
            queryset = studentStudentModel.objects.get(slug=slug)
            serializer = studentClientStudentSerializer(queryset)
            return Response(serializer.data)

    def update(self, request, slug=None):
        slug = slug
        if slug is not None:
            queryset = studentStudentModel.objects.get(slug=slug)
            serializer = studentClientStudentSerializer(instance=queryset, data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def destroy(self, request, slug=None):
        slug = slug
        if slug is not None:
            queryset = studentStudentModel.objects.get(slu=slug)
            queryset.delete()
            return Response({"msg": "successfully deleted"})

    def create(self, request):
        serializer = studentClientStudentSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({"msg": "successfully created"})
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# </editor-fold>


# <editor-fold desc="CUSTOM PAGINATION IT IS DENOTE APP LEVEL AND GLOBALLY ">
class studentClientLargeNumberpagination(PageNumberPagination):
    page_size = 10
    page_query_param = 'page_size'
    max_page_size = 100


# </editor-fold>

# <editor-fold desc="STUDENT CREATE,UPDATE,DELETE USING MODELVIEWSET WITH AUTHENTICATION AND AUTHERIZATION">
class studentClientStudentsCurd(viewsets.ModelViewSet):
    queryset = studentStudentModel.objects.all()
    serializer_class = studentClientStudentSerializer
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [BasicAuthentication, SessionAuthentication, TokenAuthentication, JWTAuthentication]
    filter_backends = [django_filters.rest_framework.DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['title', 'age']
    search_fields = ['title', 'age']
    ordering_fields = ['id', 'title']

    # default pagination
    # pagination_class = PageNumberPagination
    # pagination_class = LimitOffsetPagination
    # pagination_class = CursorPagination

    # custom pagination
    # pagination_class=studentClientLargeNumberpagination

    def perform_create(self, serializer):
        serializer.save(student=self.request.user)

    def perform_update(self, serializer):
        serializer.save(student=self.request.user)

    # <editor-fold desc="PER ACTION PERFORM IS PERMISSION OR ROLL AUTHENTICATION AND AUTHORIZATION">
    def get_permissions(self):
        """
        Instantiates and returns the list of permissions that this view requires.
        """
        if self.action == 'list':
            permission_classes = [IsAuthenticated]
        else:
            permission_classes = [IsAdminUser]
        return [permission() for permission in permission_classes]
    # </editor-fold>


# </editor-fold>


# <editor-fold desc="STUDENT CREATED AND GET ALL STUDENTS BY USING APIVIEWS">
class studentClientStudentListApiview(APIView):
    def get(selfself, request):
        student = studentStudentModel.objects.all()
        serializer = studentClientStudentSerializer(student, many=True)
        print(serializer, '===================serializers data')
        return Response(serializer.data)

    def post(self, request):
        serializer = studentClientStudentSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(student=request.user)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
# </editor-fold>


# <editor-fold desc="STUDENT DETAILS BY USING STUDENT SLUG AND CREATED BY USING APIVIEWS">
class studentClientDetailsApiview(APIView):
    def get(self,request, slug):
        student_data = studentStudentModel.objects.all()
        student = get_object_or_404(student_data, slug=slug)
        serializer=studentClientStudentSerializer(student)
        return Response(serializer.data)
    def put(self,request,slug):
        student_data = studentStudentModel.objects.all()
        student = get_object_or_404(student_data, slug=slug)
        serializer=studentClientStudentSerializer(instance=student,data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({"msg":"successfully updated","status":status.HTTP_201_CREATED})
        return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)

    def delete(self,request,slug):
        student_data = studentStudentModel.objects.all()
        student = get_object_or_404(student_data, slug=slug)
        student.delete()
        # return Response({"msg":"successfully deleted"})
        return Response(status=status.HTTP_204_NO_CONTENT)
# </editor-fold>


